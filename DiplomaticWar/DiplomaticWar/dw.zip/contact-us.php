<?php
require ('template1_imports.php');
require ('template1_header_operations.php');
require('template1_part1.php');
?>
<title>CONTACT US - DIPLOMATIC WAR</title>
<?php require('template1_part2.php'); ?>

<H1>Contact Us</H1>
General Inquiries: <a href="mailto:general@diplomatic-war.com">general@diplomatic-war.com</a>
<br>
Bug Reports: <a href="bugs.diplomatic-war.com">bugs.diplomatic-war.com</a>
<br>
Support: <a href="support.diplomatic-war.com">support.diplomatic-war.com</a>

<?php require('template1_part3.php'); ?>