<?php
require('template1_imports.php');
require ('template1_header_operations.php');
require('template1_part1.php');
?>
<title>REGISTRATION SUCCESS! - DIPLOMATIC WAR</title>
<?php require('template1_part2.php'); ?>

<p>CONGRATULATIONS! Your account is now fully registered!</p>
<p>Click <a href="http://diplomatic-war.com/index.php">here</a> to get going!</p>

<?php require('template1_part3.php'); ?>