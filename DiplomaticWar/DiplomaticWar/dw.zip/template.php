<?php require ('template1_imports.php'); ?>
<?php require ('template1_header_operations.php'); ?>
<!--Place Header Scripts Here-->

<!--No More Header Scripts Here-->
<?php require('template1_part1.php'); ?>
<title>TITLE - DIPLOMATIC WAR</title>
<?php require('template1_part2.php'); ?>
<!--Place Content Here-->

<!--No Content Beyond Here-->
<?php require('template1_part3.php'); ?>