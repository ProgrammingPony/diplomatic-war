<?php require('template1_part1.php'); ?>
<title>HOME - DIPLOMATIC WAR</title>
<?php require('template1_part2.php'); ?>
					<h1>Title</h1>
					<h2>Subtitle</h2>
					<h3>Heading1</h3>
					<h4>Heading2</h4>
					<h5>Heading3</h5>
					<ul>
						<li>UL Item1</li>
						<li>UL Item2</li>
						<li>UL Item3</li>
					</ul>
					
					<ol>
						<li>OL Item1</li>
						<li>OL Item2</li>
						<li>OL Item3</li>
					</ol>
					
					<p>A Paragraph.</p>
					<a href="#">A Link</a>
<?php require('template1_part3.php'); ?>