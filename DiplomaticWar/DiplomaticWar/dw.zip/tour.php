<?php
require('template1_imports.php');
require ('template1_header_operations.php');
?>
<!--Place Header Scripts Here-->

<!--No More Header Scripts Here-->
<?php require('template1_part1.php'); ?>
<title>THE TOUR - DIPLOMATIC WAR</title>
<?php require('template1_part2.php'); ?>
<!--Place Content Here-->
<h1>Under Construction</h1>
<!--No Content Beyond Here-->
<?php require('template1_part3.php'); ?>